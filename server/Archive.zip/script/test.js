url = encodeURI(
  "https://cpaas.messagecentral.com/verification/v3/send?countryCode=91&customerId=C-D16FD9BD35AB4BF&senderId=UTOB&type=SMS&flowType=SMS&mobileNumber=9732197206&message=hviy"
);
var options = {
  method: "POST",
  headers: {
    authToken:
      "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJDLUQxNkZEOUJEMzVBQjRCRiIsImlhdCI6MTc0MTQ5NzU2MSwiZXhwIjoxODk5MTc3NTYxfQ.mPjXxxwzy6Hn74pecckPXP27XL7KXrEIf60cYrxSiQOX_cf_1w2r2nVIIIneIBk0zL51f2PYNhjAGEF9o955RQ",
  },
};
fetch(url, options).then((e) => {
  console.log(e);
});
